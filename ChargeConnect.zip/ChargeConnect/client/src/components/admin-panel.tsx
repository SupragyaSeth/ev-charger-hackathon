import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Edit, Unlock, Lock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type { QueueEntry } from "@shared/schema";

interface AdminPanelProps {
  onNotification: (message: string, type?: string) => void;
}

export default function AdminPanel({ onNotification }: AdminPanelProps) {
  const queryClient = useQueryClient();

  const { data: queue } = useQuery<QueueEntry[]>({
    queryKey: ["/api/queue"],
  });

  const notifyNextUserMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/admin/queue/${id}/notify`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/queue"] });
      onNotification("Next user has been notified and moved to front of queue.");
    },
    onError: () => {
      onNotification("Failed to notify user.", "error");
    },
  });

  const releaseChargerMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/admin/chargers/${id}/release`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chargers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      onNotification("Charger has been released and is now available.");
    },
    onError: () => {
      onNotification("Failed to release charger.", "error");
    },
  });

  const reserveChargerMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/admin/chargers/${id}/reserve`, {
        reservedBy: "Admin",
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chargers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      onNotification("Charger has been reserved for maintenance.");
    },
    onError: () => {
      onNotification("Failed to reserve charger.", "error");
    },
  });

  const nextUser = queue && queue.length > 0 ? queue[0] : null;

  return (
    <Card className="mt-8 shadow-sm border-gray-200">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-ev-secondary mb-6">Admin Controls</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-medium text-ev-secondary mb-4">Queue Management</h3>
            <div className="space-y-3">
              {nextUser ? (
                <Button
                  variant="outline"
                  className="w-full justify-start h-auto p-4 hover:bg-gray-50"
                  onClick={() => notifyNextUserMutation.mutate(nextUser.id)}
                  disabled={notifyNextUserMutation.isPending}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="text-left">
                      <p className="font-medium text-ev-secondary">Notify Next User</p>
                      <p className="text-sm text-gray-600">Send notification to {nextUser.name}</p>
                    </div>
                    <Bell className="text-ev-primary w-5 h-5" />
                  </div>
                </Button>
              ) : (
                <div className="w-full p-4 border border-gray-200 rounded-lg bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-400">Notify Next User</p>
                      <p className="text-sm text-gray-400">No users in queue</p>
                    </div>
                    <Bell className="text-gray-300 w-5 h-5" />
                  </div>
                </div>
              )}
              
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-4 hover:bg-gray-50"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="text-left">
                    <p className="font-medium text-ev-secondary">Manage Queue Order</p>
                    <p className="text-sm text-gray-600">Reorder or remove users</p>
                  </div>
                  <Edit className="text-ev-primary w-5 h-5" />
                </div>
              </Button>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-medium text-ev-secondary mb-4">Charger Controls</h3>
            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-4 hover:bg-gray-50"
                onClick={() => releaseChargerMutation.mutate(1)}
                disabled={releaseChargerMutation.isPending}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="text-left">
                    <p className="font-medium text-ev-secondary">Release Charger</p>
                    <p className="text-sm text-gray-600">Mark charger as available</p>
                  </div>
                  <Unlock className="text-ev-success w-5 h-5" />
                </div>
              </Button>
              
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-4 hover:bg-gray-50"
                onClick={() => reserveChargerMutation.mutate(1)}
                disabled={reserveChargerMutation.isPending}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="text-left">
                    <p className="font-medium text-ev-secondary">Reserve Charger</p>
                    <p className="text-sm text-gray-600">Block charger for maintenance</p>
                  </div>
                  <Lock className="text-ev-warning w-5 h-5" />
                </div>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
