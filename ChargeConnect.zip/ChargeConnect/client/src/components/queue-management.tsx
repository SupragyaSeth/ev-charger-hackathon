import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ChevronDown, Info } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertQueueEntrySchema } from "@shared/schema";
import type { QueueEntry, InsertQueueEntry } from "@shared/schema";
import { z } from "zod";

interface QueueManagementProps {
  onNotification: (message: string, type?: string) => void;
}

const formSchema = insertQueueEntrySchema.extend({
  name: z.string().min(1, "Name is required"),
  phone: z.string().min(1, "Phone number is required"),
  vehicle: z.string().min(1, "Vehicle is required"),
});

type FormData = z.infer<typeof formSchema>;

export default function QueueManagement({ onNotification }: QueueManagementProps) {
  const [showFullQueue, setShowFullQueue] = useState(false);
  const queryClient = useQueryClient();

  const { data: queue, isLoading } = useQuery<QueueEntry[]>({
    queryKey: ["/api/queue"],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      phone: "",
      vehicle: "",
      preferredChargerType: "any",
    },
  });

  const joinQueueMutation = useMutation({
    mutationFn: async (data: InsertQueueEntry) => {
      const response = await apiRequest("POST", "/api/queue", data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/queue"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      onNotification(`Successfully joined the queue! You are #${data.position} in line.`);
      reset();
    },
    onError: () => {
      onNotification("Failed to join queue. Please try again.", "error");
    },
  });

  const onSubmit = (data: FormData) => {
    joinQueueMutation.mutate(data);
  };

  const displayedQueue = showFullQueue ? queue : queue?.slice(0, 4);
  const estimatedWait = queue && queue.length > 0 ? `${queue[0].estimatedWaitTime}-${queue[0].estimatedWaitTime + 7} minutes` : "5-10 minutes";

  return (
    <>
      <Card className="shadow-sm border-gray-200 mb-6">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold text-ev-secondary mb-4">Join Queue</h2>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <Label htmlFor="name" className="block text-sm font-medium text-ev-secondary mb-2">
                Full Name
              </Label>
              <Input
                id="name"
                {...register("name")}
                placeholder="Enter your name"
                className="focus:ring-2 focus:ring-ev-primary focus:border-transparent"
              />
              {errors.name && <p className="text-sm text-ev-error mt-1">{errors.name.message}</p>}
            </div>
            
            <div>
              <Label htmlFor="phone" className="block text-sm font-medium text-ev-secondary mb-2">
                Phone Number
              </Label>
              <Input
                id="phone"
                type="tel"
                {...register("phone")}
                placeholder="(555) 123-4567"
                className="focus:ring-2 focus:ring-ev-primary focus:border-transparent"
              />
              {errors.phone && <p className="text-sm text-ev-error mt-1">{errors.phone.message}</p>}
            </div>
            
            <div>
              <Label htmlFor="vehicle" className="block text-sm font-medium text-ev-secondary mb-2">
                Vehicle Type
              </Label>
              <Select onValueChange={(value) => setValue("vehicle", value)}>
                <SelectTrigger className="focus:ring-2 focus:ring-ev-primary focus:border-transparent">
                  <SelectValue placeholder="Select your vehicle" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Tesla Model 3">Tesla Model 3</SelectItem>
                  <SelectItem value="Tesla Model Y">Tesla Model Y</SelectItem>
                  <SelectItem value="Nissan Leaf">Nissan Leaf</SelectItem>
                  <SelectItem value="Chevrolet Bolt">Chevrolet Bolt</SelectItem>
                  <SelectItem value="BMW i3">BMW i3</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
              {errors.vehicle && <p className="text-sm text-ev-error mt-1">{errors.vehicle.message}</p>}
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-ev-secondary mb-2">
                Preferred Charger Type
              </Label>
              <RadioGroup
                defaultValue="any"
                onValueChange={(value) => setValue("preferredChargerType", value)}
                className="space-y-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="any" id="any" />
                  <Label htmlFor="any" className="text-sm">Any Available</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="level2" id="level2" />
                  <Label htmlFor="level2" className="text-sm">Level 2 (7.2kW)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="dcfast" id="dcfast" />
                  <Label htmlFor="dcfast" className="text-sm">DC Fast (50kW)</Label>
                </div>
              </RadioGroup>
            </div>
            
            <Button
              type="submit"
              className="w-full bg-ev-primary text-white hover:bg-blue-700"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Joining..." : "Join Queue"}
            </Button>
          </form>
          
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <Info className="text-ev-primary text-lg mt-0.5 w-5 h-5" />
              <div>
                <p className="text-sm font-medium text-ev-primary">Estimated Wait Time</p>
                <p className="text-sm text-gray-600 mt-1">
                  Based on current queue: <span className="font-medium">{estimatedWait}</span>
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-ev-secondary">Current Queue</h2>
            <span className="text-sm text-gray-600">Updated 2 min ago</span>
          </div>
          
          {isLoading ? (
            <div>Loading queue...</div>
          ) : !queue || queue.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>No one in queue currently</p>
            </div>
          ) : (
            <div className="space-y-3">
              {displayedQueue?.map((user, index) => (
                <div
                  key={user.id}
                  className={`flex items-center justify-between p-3 rounded-lg ${
                    index === 0
                      ? "bg-ev-primary bg-opacity-5 border border-ev-primary"
                      : "bg-gray-50"
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                        index === 0
                          ? "bg-ev-primary text-white"
                          : "bg-gray-400 text-white"
                      }`}
                    >
                      {user.position}
                    </div>
                    <div>
                      <p className="font-medium text-ev-secondary">{user.name}</p>
                      <p className="text-sm text-gray-600">{user.vehicle}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {index === 0 ? (
                      <>
                        <p className="text-sm font-medium text-ev-primary">Next up</p>
                        <p className="text-xs text-gray-500">~{user.estimatedWaitTime} min</p>
                      </>
                    ) : (
                      <>
                        <p className="text-sm text-gray-600">~{user.estimatedWaitTime} min</p>
                        <p className="text-xs text-gray-500">
                          {user.preferredChargerType === "level2"
                            ? "Level 2 preferred"
                            : user.preferredChargerType === "dcfast"
                            ? "DC Fast preferred"
                            : "Any charger"}
                        </p>
                      </>
                    )}
                  </div>
                </div>
              ))}
              
              {queue && queue.length > 4 && (
                <div className="text-center py-3">
                  <Button
                    variant="ghost"
                    onClick={() => setShowFullQueue(!showFullQueue)}
                    className="text-ev-primary hover:text-blue-700"
                  >
                    {showFullQueue ? "Show Less" : `View All ${queue.length} in Queue`}
                    <ChevronDown className="ml-1 w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
