import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  return (
    <nav className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="text-ev-primary text-2xl mr-3">⚡</div>
              <span className="text-xl font-semibold text-ev-secondary">ChargePath</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-ev-secondary hover:text-ev-primary">
              <Bell className="w-5 h-5" />
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-gray-600">JS</span>
              </div>
              <span className="text-ev-secondary text-sm">John Smith</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
