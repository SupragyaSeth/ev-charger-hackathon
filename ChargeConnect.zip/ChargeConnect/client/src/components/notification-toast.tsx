import { useEffect } from "react";
import { CheckCircle, X, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface NotificationToastProps {
  message: string;
  type: string;
  onDismiss: () => void;
}

export default function NotificationToast({ message, type, onDismiss }: NotificationToastProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss();
    }, 5000);

    return () => clearTimeout(timer);
  }, [onDismiss]);

  const getToastStyles = () => {
    switch (type) {
      case "success":
        return "bg-ev-success text-white";
      case "error":
        return "bg-ev-error text-white";
      case "warning":
        return "bg-ev-warning text-white";
      default:
        return "bg-ev-success text-white";
    }
  };

  const getIcon = () => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5" />;
      case "error":
        return <AlertCircle className="w-5 h-5" />;
      case "warning":
        return <AlertCircle className="w-5 h-5" />;
      default:
        return <CheckCircle className="w-5 h-5" />;
    }
  };

  return (
    <div className="fixed top-20 right-4 z-50 animate-in slide-in-from-right">
      <div className={`px-6 py-4 rounded-lg shadow-lg flex items-center space-x-3 max-w-sm ${getToastStyles()}`}>
        {getIcon()}
        <div className="flex-1">
          <p className="font-medium">{message}</p>
          {type === "success" && message.includes("turn") && (
            <p className="text-sm opacity-90">Proceed to your assigned charger</p>
          )}
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onDismiss}
          className="text-white hover:text-gray-200 hover:bg-transparent p-1"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
