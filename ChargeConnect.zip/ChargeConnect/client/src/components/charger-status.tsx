import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Plug, Bolt, Clock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type { Charger } from "@shared/schema";

interface ChargerStatusProps {
  isAdminMode: boolean;
  onToggleAdminMode: (enabled: boolean) => void;
  onNotification: (message: string, type?: string) => void;
}

export default function ChargerStatus({ isAdminMode, onToggleAdminMode, onNotification }: ChargerStatusProps) {
  const queryClient = useQueryClient();

  const { data: chargers, isLoading } = useQuery<Charger[]>({
    queryKey: ["/api/chargers"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const updateChargerMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Charger> }) => {
      const response = await apiRequest("PATCH", `/api/chargers/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chargers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "border-ev-success bg-ev-success bg-opacity-5";
      case "occupied":
        return "border-ev-error bg-ev-error bg-opacity-5";
      case "reserved":
        return "border-ev-warning bg-ev-warning bg-opacity-5";
      default:
        return "border-gray-200 bg-gray-50";
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-ev-success text-white";
      case "occupied":
        return "bg-ev-error text-white";
      case "reserved":
        return "bg-ev-warning text-white";
      default:
        return "bg-gray-400 text-white";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "available":
        return <Plug className="text-ev-success text-lg w-5 h-5" />;
      case "occupied":
        return <Bolt className="text-ev-error text-lg w-5 h-5" />;
      case "reserved":
        return <Clock className="text-ev-warning text-lg w-5 h-5" />;
      default:
        return <Plug className="text-gray-400 text-lg w-5 h-5" />;
    }
  };

  if (isLoading) {
    return (
      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-6">
          <div>Loading chargers...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm border-gray-200">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-ev-secondary">Charger Status</h2>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-ev-success rounded-full"></div>
              <span className="text-sm text-gray-600">Available</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-ev-error rounded-full"></div>
              <span className="text-sm text-gray-600">Occupied</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-ev-warning rounded-full"></div>
              <span className="text-sm text-gray-600">Reserved</span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {chargers?.map((charger) => (
            <div
              key={charger.id}
              className={`border rounded-lg p-4 ${getStatusColor(charger.status)}`}
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-medium text-ev-secondary">{charger.name}</h3>
                  <p className="text-sm text-gray-600">{charger.type === "level2" ? "Level 2" : "DC Fast"} - {charger.power}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-medium rounded capitalize ${getStatusBadgeColor(charger.status)}`}>
                  {charger.status}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  {charger.status === "occupied" && charger.currentUser && (
                    <>
                      <span className="text-sm text-gray-600">{charger.currentUser}</span>
                      <p className="text-xs text-gray-500">~{charger.estimatedTimeRemaining} min remaining</p>
                    </>
                  )}
                  {charger.status === "reserved" && charger.reservedBy && (
                    <>
                      <span className="text-sm text-gray-600">{charger.reservedBy}</span>
                      <p className="text-xs text-gray-500">Reserved until 3:30 PM</p>
                    </>
                  )}
                  {charger.status === "available" && (
                    <span className="text-sm text-gray-600">Ready for use</span>
                  )}
                </div>
                {getStatusIcon(charger.status)}
              </div>
            </div>
          ))}
        </div>
        
        <div className="border-t border-gray-200 pt-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-ev-secondary">Admin Mode</span>
            <Switch
              checked={isAdminMode}
              onCheckedChange={onToggleAdminMode}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
