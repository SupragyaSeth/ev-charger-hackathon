import { useState, useEffect } from "react";
import Navigation from "@/components/navigation";
import ChargerStatus from "@/components/charger-status";
import QueueManagement from "@/components/queue-management";
import AdminPanel from "@/components/admin-panel";
import NotificationToast from "@/components/notification-toast";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Plug, Bolt, Clock, HourglassIcon } from "lucide-react";

interface DashboardStats {
  available: number;
  inUse: number;
  queueLength: number;
  avgWait: string;
}

export default function Dashboard() {
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [notification, setNotification] = useState<{ message: string; type: string } | null>(null);

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const showNotification = (message: string, type: string = "success") => {
    setNotification({ message, type });
  };

  const dismissNotification = () => {
    setNotification(null);
  };

  // Auto-dismiss notification after 5 seconds
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  return (
    <div className="min-h-screen bg-ev-surface">
      <Navigation />
      
      {notification && (
        <NotificationToast
          message={notification.message}
          type={notification.type}
          onDismiss={dismissNotification}
        />
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-ev-secondary mb-2">EV Charging Station Dashboard</h1>
          <p className="text-gray-600 mb-6">Manage your charging queue and monitor station availability</p>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="shadow-sm border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-ev-success bg-opacity-10 rounded-lg">
                    <Plug className="text-ev-success text-xl w-6 h-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Available</p>
                    <p className="text-2xl font-semibold text-ev-secondary">
                      {statsLoading ? "..." : stats?.available || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow-sm border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-ev-error bg-opacity-10 rounded-lg">
                    <Bolt className="text-ev-error text-xl w-6 h-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">In Use</p>
                    <p className="text-2xl font-semibold text-ev-secondary">
                      {statsLoading ? "..." : stats?.inUse || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow-sm border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-ev-warning bg-opacity-10 rounded-lg">
                    <Clock className="text-ev-warning text-xl w-6 h-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Queue Length</p>
                    <p className="text-2xl font-semibold text-ev-secondary">
                      {statsLoading ? "..." : stats?.queueLength || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow-sm border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-ev-primary bg-opacity-10 rounded-lg">
                    <HourglassIcon className="text-ev-primary text-xl w-6 h-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Avg. Wait</p>
                    <p className="text-2xl font-semibold text-ev-secondary">
                      {statsLoading ? "..." : stats?.avgWait || "0 min"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <ChargerStatus 
              isAdminMode={isAdminMode} 
              onToggleAdminMode={setIsAdminMode}
              onNotification={showNotification}
            />
          </div>
          
          <div>
            <QueueManagement onNotification={showNotification} />
          </div>
        </div>

        {isAdminMode && (
          <AdminPanel onNotification={showNotification} />
        )}
      </div>
    </div>
  );
}
