import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const chargers = pgTable("chargers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // "level2" or "dcfast"
  power: text("power").notNull(), // "7.2kW" or "50kW"
  status: text("status").notNull(), // "available", "occupied", "reserved"
  currentUser: text("current_user"),
  estimatedTimeRemaining: integer("estimated_time_remaining"), // in minutes
  reservedBy: text("reserved_by"),
  reservedUntil: timestamp("reserved_until"),
});

export const queueEntries = pgTable("queue_entries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  vehicle: text("vehicle").notNull(),
  preferredChargerType: text("preferred_charger_type").notNull(), // "any", "level2", "dcfast"
  position: integer("position").notNull(),
  estimatedWaitTime: integer("estimated_wait_time"), // in minutes
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export const insertChargerSchema = createInsertSchema(chargers).omit({
  id: true,
});

export const insertQueueEntrySchema = createInsertSchema(queueEntries).omit({
  id: true,
  position: true,
  estimatedWaitTime: true,
  joinedAt: true,
});

export type InsertCharger = z.infer<typeof insertChargerSchema>;
export type Charger = typeof chargers.$inferSelect;
export type InsertQueueEntry = z.infer<typeof insertQueueEntrySchema>;
export type QueueEntry = typeof queueEntries.$inferSelect;
