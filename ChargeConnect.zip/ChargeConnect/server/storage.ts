import { chargers, queueEntries, type Charger, type InsertCharger, type QueueEntry, type InsertQueueEntry } from "@shared/schema";

export interface IStorage {
  // Charger methods
  getChargers(): Promise<Charger[]>;
  getCharger(id: number): Promise<Charger | undefined>;
  updateCharger(id: number, updates: Partial<Charger>): Promise<Charger | undefined>;
  createCharger(charger: InsertCharger): Promise<Charger>;
  
  // Queue methods
  getQueueEntries(): Promise<QueueEntry[]>;
  addToQueue(entry: InsertQueueEntry): Promise<QueueEntry>;
  removeFromQueue(id: number): Promise<boolean>;
  updateQueueEntry(id: number, updates: Partial<QueueEntry>): Promise<QueueEntry | undefined>;
  reorderQueue(): Promise<void>;
}

export class MemStorage implements IStorage {
  private chargers: Map<number, Charger>;
  private queueEntries: Map<number, QueueEntry>;
  private currentChargerId: number;
  private currentQueueId: number;

  constructor() {
    this.chargers = new Map();
    this.queueEntries = new Map();
    this.currentChargerId = 1;
    this.currentQueueId = 1;
    
    // Initialize with default chargers
    this.initializeChargers();
  }

  private initializeChargers() {
    const defaultChargers: InsertCharger[] = [
      { name: "Charger #1", type: "level2", power: "7.2kW", status: "available", currentUser: null, estimatedTimeRemaining: null, reservedBy: null, reservedUntil: null },
      { name: "Charger #2", type: "level2", power: "7.2kW", status: "occupied", currentUser: "Sarah Johnson", estimatedTimeRemaining: 45, reservedBy: null, reservedUntil: null },
      { name: "Charger #3", type: "dcfast", power: "50kW", status: "occupied", currentUser: "Mike Chen", estimatedTimeRemaining: 20, reservedBy: null, reservedUntil: null },
      { name: "Charger #4", type: "dcfast", power: "50kW", status: "reserved", currentUser: null, estimatedTimeRemaining: null, reservedBy: "Alex Rivera", reservedUntil: new Date() },
      { name: "Charger #5", type: "level2", power: "7.2kW", status: "available", currentUser: null, estimatedTimeRemaining: null, reservedBy: null, reservedUntil: null },
      { name: "Charger #6", type: "level2", power: "7.2kW", status: "occupied", currentUser: "Emma Wilson", estimatedTimeRemaining: 75, reservedBy: null, reservedUntil: null },
    ];

    defaultChargers.forEach(charger => {
      const id = this.currentChargerId++;
      this.chargers.set(id, { ...charger, id });
    });
  }

  async getChargers(): Promise<Charger[]> {
    return Array.from(this.chargers.values());
  }

  async getCharger(id: number): Promise<Charger | undefined> {
    return this.chargers.get(id);
  }

  async updateCharger(id: number, updates: Partial<Charger>): Promise<Charger | undefined> {
    const charger = this.chargers.get(id);
    if (!charger) return undefined;
    
    const updatedCharger = { ...charger, ...updates };
    this.chargers.set(id, updatedCharger);
    return updatedCharger;
  }

  async createCharger(insertCharger: InsertCharger): Promise<Charger> {
    const id = this.currentChargerId++;
    const charger: Charger = { ...insertCharger, id };
    this.chargers.set(id, charger);
    return charger;
  }

  async getQueueEntries(): Promise<QueueEntry[]> {
    return Array.from(this.queueEntries.values()).sort((a, b) => a.position - b.position);
  }

  async addToQueue(insertEntry: InsertQueueEntry): Promise<QueueEntry> {
    const id = this.currentQueueId++;
    const position = this.queueEntries.size + 1;
    const estimatedWaitTime = this.calculateEstimatedWaitTime(position, insertEntry.preferredChargerType);
    
    const entry: QueueEntry = {
      ...insertEntry,
      id,
      position,
      estimatedWaitTime,
      joinedAt: new Date(),
    };
    
    this.queueEntries.set(id, entry);
    return entry;
  }

  async removeFromQueue(id: number): Promise<boolean> {
    const removed = this.queueEntries.delete(id);
    if (removed) {
      await this.reorderQueue();
    }
    return removed;
  }

  async updateQueueEntry(id: number, updates: Partial<QueueEntry>): Promise<QueueEntry | undefined> {
    const entry = this.queueEntries.get(id);
    if (!entry) return undefined;
    
    const updatedEntry = { ...entry, ...updates };
    this.queueEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async reorderQueue(): Promise<void> {
    const entries = Array.from(this.queueEntries.values()).sort((a, b) => a.position - b.position);
    
    entries.forEach((entry, index) => {
      const newPosition = index + 1;
      const estimatedWaitTime = this.calculateEstimatedWaitTime(newPosition, entry.preferredChargerType);
      
      this.queueEntries.set(entry.id, {
        ...entry,
        position: newPosition,
        estimatedWaitTime,
      });
    });
  }

  private calculateEstimatedWaitTime(position: number, preferredType: string): number {
    const availableChargers = Array.from(this.chargers.values()).filter(c => c.status === "available");
    const occupiedChargers = Array.from(this.chargers.values()).filter(c => c.status === "occupied");
    
    if (availableChargers.length > 0 && position === 1) {
      return 5; // Ready soon
    }
    
    // Average charging time: Level 2 = 60 minutes, DC Fast = 30 minutes
    const avgChargingTime = preferredType === "dcfast" ? 30 : preferredType === "level2" ? 60 : 45;
    const avgWaitPerPosition = avgChargingTime / Math.max(this.chargers.size, 1);
    
    return Math.round(position * avgWaitPerPosition);
  }
}

export const storage = new MemStorage();
