import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQueueEntrySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all chargers
  app.get("/api/chargers", async (req, res) => {
    try {
      const chargers = await storage.getChargers();
      res.json(chargers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chargers" });
    }
  });

  // Update charger status
  app.patch("/api/chargers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const updatedCharger = await storage.updateCharger(id, updates);
      if (!updatedCharger) {
        return res.status(404).json({ message: "Charger not found" });
      }
      
      res.json(updatedCharger);
    } catch (error) {
      res.status(500).json({ message: "Failed to update charger" });
    }
  });

  // Get queue entries
  app.get("/api/queue", async (req, res) => {
    try {
      const queue = await storage.getQueueEntries();
      res.json(queue);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch queue" });
    }
  });

  // Join queue
  app.post("/api/queue", async (req, res) => {
    try {
      const validatedData = insertQueueEntrySchema.parse(req.body);
      const queueEntry = await storage.addToQueue(validatedData);
      res.json(queueEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to join queue" });
    }
  });

  // Remove from queue
  app.delete("/api/queue/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const removed = await storage.removeFromQueue(id);
      
      if (!removed) {
        return res.status(404).json({ message: "Queue entry not found" });
      }
      
      res.json({ message: "Removed from queue successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove from queue" });
    }
  });

  // Admin: Move queue entry to next position
  app.post("/api/admin/queue/:id/notify", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const entry = await storage.updateQueueEntry(id, { position: 0 }); // Move to front
      
      if (!entry) {
        return res.status(404).json({ message: "Queue entry not found" });
      }
      
      await storage.reorderQueue();
      res.json({ message: "User notified and moved to front" });
    } catch (error) {
      res.status(500).json({ message: "Failed to notify user" });
    }
  });

  // Admin: Release charger
  app.post("/api/admin/chargers/:id/release", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updatedCharger = await storage.updateCharger(id, {
        status: "available",
        currentUser: null,
        estimatedTimeRemaining: null,
      });
      
      if (!updatedCharger) {
        return res.status(404).json({ message: "Charger not found" });
      }
      
      res.json(updatedCharger);
    } catch (error) {
      res.status(500).json({ message: "Failed to release charger" });
    }
  });

  // Admin: Reserve charger
  app.post("/api/admin/chargers/:id/reserve", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { reservedBy } = req.body;
      
      const updatedCharger = await storage.updateCharger(id, {
        status: "reserved",
        reservedBy: reservedBy || "Admin",
        reservedUntil: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
      });
      
      if (!updatedCharger) {
        return res.status(404).json({ message: "Charger not found" });
      }
      
      res.json(updatedCharger);
    } catch (error) {
      res.status(500).json({ message: "Failed to reserve charger" });
    }
  });

  // Get dashboard stats
  app.get("/api/stats", async (req, res) => {
    try {
      const chargers = await storage.getChargers();
      const queue = await storage.getQueueEntries();
      
      const available = chargers.filter(c => c.status === "available").length;
      const inUse = chargers.filter(c => c.status === "occupied").length;
      const queueLength = queue.length;
      
      const occupiedChargers = chargers.filter(c => c.status === "occupied");
      const avgWait = occupiedChargers.length > 0 
        ? Math.round(occupiedChargers.reduce((sum, c) => sum + (c.estimatedTimeRemaining || 0), 0) / occupiedChargers.length)
        : 0;
      
      res.json({
        available,
        inUse,
        queueLength,
        avgWait: `${avgWait} min`,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
