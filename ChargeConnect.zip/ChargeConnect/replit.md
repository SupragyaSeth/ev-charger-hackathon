# EV Charger Management System

## Overview

This is a full-stack web application for managing electric vehicle (EV) charging stations. The system provides real-time monitoring of charger status, queue management for users waiting to charge, and administrative controls for managing the charging infrastructure.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom EV-themed color palette
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Express sessions with PostgreSQL store
- **Data Storage**: Currently using in-memory storage (MemStorage) as fallback

### Key Design Decisions
1. **Monorepo Structure**: Single repository with client, server, and shared code
2. **Type Safety**: Full TypeScript implementation with shared types between frontend and backend
3. **Real-time Updates**: Polling-based updates every 5-30 seconds for different data types
4. **Responsive Design**: Mobile-first approach with Tailwind CSS
5. **Component Architecture**: Modular UI components following atomic design principles

## Key Components

### Database Schema (`shared/schema.ts`)
- **Chargers Table**: Stores charger information including status, current user, and reservation details
- **Queue Entries Table**: Manages user queue with position tracking and wait time estimates
- **Type Definitions**: Shared TypeScript types for type safety across the stack

### Frontend Components
- **Dashboard**: Main view combining charger status and queue management
- **ChargerStatus**: Real-time display of all charging stations
- **QueueManagement**: Interface for joining and viewing the charging queue
- **AdminPanel**: Administrative controls for managing chargers and queue
- **Navigation**: Top navigation with user context

### Backend Services
- **Storage Interface**: Abstracted storage layer supporting both in-memory and database persistence
- **REST API**: CRUD operations for chargers and queue management
- **Admin Endpoints**: Special endpoints for administrative operations

### Authentication & Authorization
- Currently implements basic session-based authentication
- Admin mode toggle for elevated permissions
- No complex user roles - binary user/admin distinction

## Data Flow

### User Journey
1. **View Status**: Users see current charger availability and queue status
2. **Join Queue**: Users can join the waiting queue with their details
3. **Real-time Updates**: System polls for status updates every 5-30 seconds
4. **Notifications**: Toast notifications inform users of important events
5. **Admin Actions**: Administrators can manage chargers and notify users

### Data Synchronization
- **Optimistic Updates**: UI updates immediately, then syncs with server
- **Error Handling**: Graceful degradation with user-friendly error messages
- **Cache Invalidation**: TanStack Query automatically manages cache updates
- **Polling Strategy**: Different polling intervals for different data types

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for Neon database
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/react-***: Accessible UI primitives
- **react-hook-form**: Form state management
- **zod**: Runtime type validation

### Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Static type checking
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler for production

### Database Setup
- Requires `DATABASE_URL` environment variable
- Uses Drizzle migrations for schema management
- Supports both development and production PostgreSQL instances

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React app to `dist/public`
2. **Backend Build**: ESBuild bundles server code to `dist/index.js`
3. **Static Assets**: Frontend assets served by Express in production
4. **Environment**: NODE_ENV determines development vs production behavior

### Development Workflow
- **Hot Reload**: Vite provides fast hot module replacement
- **Type Checking**: Continuous TypeScript compilation
- **Database Migrations**: `npm run db:push` applies schema changes
- **Concurrent Development**: Single command runs both frontend and backend

### Production Considerations
- **Session Store**: Uses PostgreSQL for session persistence
- **Static File Serving**: Express serves built frontend assets
- **Environment Variables**: Requires database connection string
- **Process Management**: Single Node.js process handles both API and static content

### Scaling Considerations
- **Database**: Uses connection pooling with Neon serverless
- **Caching**: TanStack Query provides client-side caching
- **Real-time**: Currently polling-based, could be upgraded to WebSockets
- **CDN**: Static assets could be served from CDN in production